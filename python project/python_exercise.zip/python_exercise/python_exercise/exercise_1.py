import pygame
#初始化
pygame.init()
screen=pygame.display.set_mode((800,600))
#让窗口做停留操作
#标题和图片
pygame.display.set_caption("space invaders")
icon=pygame.image.load('ufo.png')
pygame.display.set_icon(icon)
#玩家
playerimg=pygame.image.load('player.png')
playerx=370
playerY=4803

def player():
    screen.blit(playerimg,(playerx,playerY))

#游戏循环
running=True
while running:
    screen.fill((0, 0, 0))
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            running=False


    #rgb=red,green,blue

    player()
    pygame.display.update()



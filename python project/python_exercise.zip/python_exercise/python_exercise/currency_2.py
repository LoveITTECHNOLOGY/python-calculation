"""
作者:魏家福
功能:汇率兑换
版本:2.0
日期:28/02/2020


"""

#汇率
USD_VS_RMB=6.77
#输入，input输入默认的字符串类型
currency_str_value=input("请输入带单位的货币金额:")
#获取货币单位
unit=currency_str_value[-3:]
#分支选择
if unit=='CNY':
    #输入的是人名币
    rmb_str_value=currency_str_value[:-3]
    #将字符串转换成数字
    rmb_value=eval(rmb_str_value)
    #汇率转换
    usd_value=rmb_value/USD_VS_RMB
    print("美元(USD)金额为：",usd_value)
elif unit=='USD':
    #输入的是美元
    usd_str_value=currency_str_value[:-3]
    #将字符串转换为数字
    usd_value=eval(currency_str_value)
    #汇率转换
    rmb_value=usd_value*USD_VS_RMB
    #输出
    print("人民币(RMB)金额:",rmb_value)
else:
    print("当前货币不支持")



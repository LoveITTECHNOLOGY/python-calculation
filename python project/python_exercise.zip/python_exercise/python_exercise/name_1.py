"""
作者:魏家福
功能:汇率兑换
版本:1.0
日期:28/02/2020


"""

print("==汇率兑换V 1.0==")

#开始输入数据
rmb=input("请输入人名币(CNY)金额:")
usd=input("请输入美元(USD)金额:")

#美元汇率
usd_currency_rate=6.77
#强制转换
rmb_value=eval(rmb)
usd_value=eval(usd)
#美元
usd=rmb_value/usd_currency_rate
#人名币
rmb=usd_value*usd_currency_rate

print("可兑换的美元为:",usd)
print("可兑换的人名币为:",rmb)
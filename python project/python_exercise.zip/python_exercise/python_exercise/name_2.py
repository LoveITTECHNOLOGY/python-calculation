"""
作者:魏嘉福
日期：28/2/2020


"""
print("===汇率计算0.1==")
#确定美元的货币汇率
USD_VS_RMB=6.7
#设置输入货币的框
currency_str_currency=input("请输入金额(或按Q退出程序)")
#开始执行循环结构由用户决定货币种类
while currency_str_currency !='Q':
    #开始确定货币的位置
    currency_value=currency_str_currency[-3:]
    #开始判断条件
    if  currency_value =='USD':
        #开始确定可兑换出的人名币货币位置
        rmb_str_currency=currency_str_currency[:-3]
        #开始将字符串转换为数字型
        rmb_value=eval(rmb_str_currency)
        #开始确定汇率
        rmb_value=rmb_value*USD_VS_RMB
        #输出
        print("人名币金额为:",rmb_value)
    elif currency_value=='RMB':
        #确定可兑换出的美元的位置
        usd_str_currency=currency_str_currency[:-3]
        #将字符串型转换为数字型
        usd_value=eval(usd_str_currency)
        #确定汇率
        usd_value=usd_value/USD_VS_RMB
        print("美元金额为:",usd_value)
    else:
     print("次货币不支持")
    currency_str_currency = input("请输入金额(或按Q退出程序)")
print("程序已退出")
"""
作者:魏家福
功能:汇率兑换
版本:3.0
日期:28/02/2020
2.0新增功能根据输入判断是人名币还是美元完成相应的运算
3.0新功能 可循环选择性退出


"""
#美元汇率
USD_CURRENCY_VS_RMB=6.77
#输入货币金额
currency_str_value=input("请输入货币金额(退出程序请输入Q):")
#开始写判断结构
while currency_str_value !='Q':
    unit = currency_str_value[-3:]

    #分支结构
    if unit=='USD':
        rmb_str_value=currency_str_value[:-3]
        #将字符串转换为数字
        rmb_value=eval(rmb_str_value)
        #汇率转换
        rmb_value=rmb_value*USD_CURRENCY_VS_RMB
        print("人民币金额:",rmb_value)
    elif unit=='CNY':
        usd_str_value=currency_str_value[:-3]
        #转换为数值
        usd_value=eval(usd_str_value)
        #汇率转换
        usd_value=usd_value*USD_CURRENCY_VS_RMB
        print("人名币为:",usd_value)
    else:
        print("当前版本不支持")
    currency_str_value = input("请输入货币金额(退出程序请输入Q):")

print('程序已退出')
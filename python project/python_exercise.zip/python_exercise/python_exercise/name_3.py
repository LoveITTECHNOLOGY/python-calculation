from tkinter import *



cal=Tk()
cal.title("the")
label_1=Label(cal,text="我对学习Python很期待！")
label_1.pack()
cal.mainloop()
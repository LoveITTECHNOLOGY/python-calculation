
def main():
    """
    主函数
    """
    y_or_n= input('请确定是否进行计算(y/n)?')
    while y_or_n=='y':
        print("请输入以下信息，各数据之间用空格分隔")
        input_str=input('性别 体重(kg) 身高(cm) 年龄')
        #用split方法进行字符串的字符串分割
        #分隔后是一个列表，【‘男’，‘75’，‘180’，‘29’】
        str_list=input_str.split(' ')
        gender=str_list[0]
        weight=float(str_list[1])
        height=float(str_list[2])
        age=int(str_list[3])
        if gender=='男':
            bmr=(13.7*weight)+(5.0*height)-(6.8*age)+66
        elif gender=='女':
            bmr=(9.6*weight)+(1.8*height)-(4.7*age)+655
        else:
            bmr=-1
        #0 进行输出数据
        if bmr==-1:
            print("性别输入信息有误，请进行核对")
        else:
            print("你的基础代谢率是{}大卡".format(bmr))
    y_or_n=input("请确定是否进行计算(y/n)?")
    print("计算已结束·")



if __name__=='__main__':
    main()
def main():
    """
    主函数
    """
    y_or_n= input('请确定是否进行计算(y/n)?')
    while y_or_n=='y':
        #性别
        gender = input('请输入性别:')
        #体重(kg)
        weight = float(input('请输入体重(kg):'))
        #身高(cm)
        height = float(input('请输入身高(cm):'))
        #年龄
        age = int(input('请输入年龄:'))
        #使用if语句完成BMR的计算
        if gender == '男':
            bmr = (13.7 * weight) + (5.0 * height) - (6.8 * age) + 66
        elif gender == '女':
            bmr = (9.6 * weight) + (1.8 * height) - (4.7 * age) + 655
        print('计算后的结果:', bmr)
        y_or_n = input('请确定是否进行计算(y/n)?')
    print('计算已结束')

if __name__=='__main__':
    main()
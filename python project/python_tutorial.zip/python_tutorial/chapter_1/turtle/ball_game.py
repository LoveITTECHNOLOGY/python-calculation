import random
import time
from tkinter import *


# 下面定义一个球的类，有canvas和color两个对象
class Ball:  # 定义一个Ball类的函数
    def __init__(self, canvas, paddle, color):  # 这是Ball类的属性函数，Ball类下的函数都有这些性质
        self.canvas = canvas
        self.paddle = paddle
        self.id = canvas.create_oval(10, 10, 25, 25, fill=color)  # 返回所绘小球的调用值放入对象self.id
        self.canvas.move(self.id, 245, 100)  # 移动小球到（245，100）坐标处，
        starts = [-3, -2, -1, 1, 2, 3]
        random.shuffle(starts)
        self.x = starts[0]  # 使得小球左右方向运动随机
        self.y = -3  # 默认开始的小球向上方运动
        self.canvas_height = self.canvas.winfo_height()  # 画布高度函数winfo_height()返回值放入canvas_height对象中
        self.canvas_width = self.canvas.winfo_width()  # winfo_width()返回画布宽度放入canvas_width对象中
        self.hit_bottom = False  # 设定hit_bottom初始值为false

    def hit_paddle(self, pos):  # 声明函数，以供调用
        paddle_pos = self.canvas.coords(self.paddle.id)  # 将球拍的(x1,y1)(x2,y2)的坐标放到paddle_pos中
        if pos[2] >= paddle_pos[0] and pos[0] <= paddle_pos[2]:  #
            if pos[3] >= paddle_pos[1] and pos[3] <= paddle_pos[3]:  # 比较小球y轴是否在球拍y轴内
                return True  # 表示小球碰到了球拍
        return False  # 表示小球没有碰到球拍

    def draw(self):  # 声明draw函数，
        self.canvas.move(self.id, self.x, self.y)  # 移动小球，移动速度为（self.x,self.y），在init中的属性可以直接用
        pos = self.canvas.coords(self.id)  # 把小球的左上角和右下角的坐标以列表形式（可能元组）放入pos对象中
        if pos[1] <= 0:  # 如果小球碰到画布上方
            self.y = 3  # 则改变移动方向向下方
        if pos[3] >= self.canvas_height:  # 如果小球碰到画布底端 则返回hit_bottom为True
            self.hit_bottom = True
        if self.hit_paddle(pos) == True:  # 小球碰到了球拍，则改变Y轴方向向上运动
            self.y = -3
        if pos[0] <= 0:  # 如果小球碰到了画布左边，则把X轴速度改成每次向右3个像素
            self.x = 3
        if pos[2] >= self.canvas_width:  # 如果小球碰到了画布右边，则把速度改成每次向左3个像素
            self.x = -3


class Paddle:  # 定义一个paddle类
    def __init__(self, canvas, color):  # paddle类的属性函数，默认有两个变量画布和颜色
        self.canvas = canvas  # 将canvas对象赋给self.canvas
        self.id = canvas.create_rectangle(0, 0, 100, 10, fill=color)  # 创建球拍，将球拍的调用编号存入self.id
        self.canvas.move(self.id, 200, 300)  # 将球拍移动到（200，300）处
        self.x = 0  #
        self.canvas_width = self.canvas.winfo_width()  # 将画布的宽度放入canvas_width对象
        self.canvas.bind_all('<KeyPress-Left>', self.turn_left)  # 用bind_all()函数绑定键盘左键与tun_left函数
        self.canvas.bind_all('<KeyPress-Right>', self.turn_right)  # 绑定键盘右键与turn_right函数

    def draw(self):  # 声明一个draw函数
        self.canvas.move(self.id, self.x, 0)  # 左右移动球拍的速度为self.x，默认不动
        pos = self.canvas.coords(self.id)  # 将球拍的左上角和右下角的坐标存入pos对象中
        if pos[0] <= 0:  # 如果球拍x轴小于0，则不再向右移动
            self.x = 0
        elif pos[2] >= self.canvas_width:  # 如果球拍要超过画布右侧了，则球拍的移动速度变为0
            self.x = 0

    def turn_left(self, evt):  # 这里的evt是调用方传过来的参数，改变球拍的移动速度向左，
        self.x = -5

    def turn_right(self, evt):  # 改变球拍的移动速度向右每次5个像素
        self.x = 5


# 创建框架并且命名和固定，然后创建该框架的画布
tk = Tk()  # 创建框架对象tk
tk.title('Game')  # 框架对象tk显示的名字为'game'
tk.resizable(0, 0)  # 固定框架
tk.wm_attributes('-topmost', 1)  # 显示在最外层
canvas = Canvas(tk, width=500, height=400, bd=0, highlightthickness=0)  # 创建画布canvas，属于tk框架对象，
canvas.pack()  # 显示画布的变化
tk.update()  # 显示框架的变化

# 把类赋值给对象ball，如果调用了ball就可以实现该类的作用
paddle = Paddle(canvas, "blue")  # 调用拍的类给对象paddle用
ball = Ball(canvas, paddle, 'green')  # 调用球的类给对象ball用

while True:  # 要注意while语句以防止死循环，先设置为真
    if ball.hit_bottom == False:  # 没有碰到底部的话执行下面的语句
        ball.draw()  # 调用ball对象的函数draw（）
        paddle.draw()  # 调用paddle对象的函数draw（）
        tk.update_idletasks()
        tk.update()  # 更新框架
        time.sleep(0.01)  # 睡眠0.01秒
    elif ball.hit_bottom == True:  # 要是小球接触了底部
        canvas.create_text(200, 100, text='对不起,你失败了\n请重试一下?',
                           font=('Times', 22))  # 在（200，100）坐标处创建文本‘...’，字号22号
        tk.update()  # 更新内容
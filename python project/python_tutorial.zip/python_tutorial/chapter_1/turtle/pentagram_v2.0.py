"""

 作者魏嘉福
 版本 2.0
 日期 8/05/2020
 功能 绘制五角星


"""
import turtle

#绘制五角星的函数
def draw_recursive_pentagram(leng):
    """
        迭代绘制五角星
        自己调用自己
    """
    count = 1
    while count <= 5:
        turtle.forward(leng)  # 向前走50
        turtle.right(144)     #向右转144度
        count += 1

    #五角星绘制完成，更新参数
    leng += 10
    if leng <= 100:
        draw_recursive_pentagram(leng)


def main():
    """
       主函数
    """
    turtle.penup()
    turtle.backward(100)
    turtle.pendown()
    turtle.pensize(2)
    turtle.pencolor('red')

    segment = 50
    draw_recursive_pentagram(segment)

    turtle.exitonclick()


if __name__ == '__main__':
    main()
turtle.mainloop()

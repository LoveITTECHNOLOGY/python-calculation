"""
    作者：魏嘉福
    功能：利用递归函数绘制分形树
    版本：1.0

"""
import turtle as t1




def draw_branch(branch_length,branch_angle):
    """
        绘制分形树
    """
    if branch_length >= 3:
        # 绘制右侧树枝
        t1.forward(branch_length)#往前画
        t1.right(branch_angle)#往右转
        draw_branch(branch_length - 15,branch_angle)

        # 绘制左侧树枝
        t1.left(2*branch_angle)#转右画左
        print('左转 ')
        draw_branch(branch_length - 15,branch_angle)

        # 返回之前的树枝
        t1.rt(branch_angle)#转到正向上的方向。然后回到上一层
        if branch_length<=30: #树枝小于30，可以作为树叶了，树叶部分为green
            t1.pencolor("forestgreen")
        if branch_length>30:
            t1.pencolor('brown') #树干为棕色
        t1.backward(branch_length)#往回画，画到上一层


def main():
    """
        主函数
    """
    t1.penup()
    t1.left(90)
    t1.backward(250)
    t1.pendown()
    t1.width(10)
    t1.speed(100)#速度
    branch_length=130
    branch_angle=20
    draw_branch(branch_length,branch_angle)
    t1.exitonclick()


if __name__ == '__main__':
    main()
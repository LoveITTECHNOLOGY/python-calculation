"""

 作者魏嘉福
 版本 1.0
 日期 8/05/2020
 功能 绘制五角星


"""
import  turtle


def main():
    count=1
    while count<=5:

        turtle.forward(200)
        turtle.right(144)
        count+=1
        #turtle.forward(200)
        #turtle.right(144)
        #turtle.forward(200)
        #turtle.right(144)
        #turtle.forward(200)
        #turtle.right(144)
        #turtle.forward(200)
        #turtle.right(144)





if __name__=='__main__':

    main()
turtle.mainloop()
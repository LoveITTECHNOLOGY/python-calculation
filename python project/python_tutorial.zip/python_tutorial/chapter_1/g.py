#开始写美元汇率
USD_VS_RMB=6.7
generate=input("输入货币种类·:")
#开始将设置人民币字符位置
str_generate_site = generate[-3:]
def convert_currency():
    pass
unit=str_generate_site
if unit=='RMB':
        #开始设置美元位置
        usd_generate_site=generate[:-3]
        #开始将字符串转换为整型
        usd_value=eval(usd_generate_site)
        #开始实现运算
        print(usd_value/USD_VS_RMB)
elif unit=='USD':
        #开始设置人名币位置
        rmb_generate_site=generate[:-3]
        #将字符串转换为数字型
        rmb_value=eval(rmb_generate_site)
        #开始计算
        print(rmb_value*USD_VS_RMB)
else:
        print("当前版本不支持")
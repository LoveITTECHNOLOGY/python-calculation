

def main():
    usd_vs_rmb = 6.77                              # 暂设汇率为6.77
    currency_str_value = input('请输入带单位的货币金额：')
    unit = currency_str_value[-3:]                  # 获取单位
    if unit == 'CNY':
        exchange_rate = 1/usd_vs_rmb
    elif unit == 'USD':
        exchange_rate = usd_vs_rmb
    else:
        # 其他情况
        exchange_rate = -1

    if exchange_rate != -1:
        in_money = eval(currency_str_value[:-3])
        # 使用lambda定义函数
        convert_currency2 = lambda x : x*exchange_rate
        # 调用函数
        # out_money = convert_currency(in_money, exchange_rate)
        # 调用lambda函数
        out_money = convert_currency2(in_money)
        print('兑换后的金额', out_money)
    else:
        print('目前版本尚不支持该种货币！')
# __name__一直为__main__，所以为真，执行main函数（不调用main函数，它是不会执行的，函数没有结果）
if __name__ == "__main__":
     main()  # 通常都是这么调用主函数

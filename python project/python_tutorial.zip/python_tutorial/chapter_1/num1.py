"""
作者:魏嘉福
时间:3/7/2020


"""
def main():
    """
    主函数
    :return:
    """
    #性别
    gender='女'
    #体重(kg)
    weight=50
    #身高(cm)
    height=168
    #年龄
    age=25
    #使用ig语句来完成BMR的计算
    if gender=='男':
        bmr=(13.7*weight)+(5.0*height)-(6.8*age)+66
    elif gender=='女':
        bmr=(9.6*weight)+(1.8*height)-(4.7*age)+655
        print("计算最后的结果:",bmr)
if __name__=='__main__':
    main\


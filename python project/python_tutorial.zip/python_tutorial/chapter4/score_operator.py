"""
作者:魏嘉福
版本·1.0
日期:20/03/2020
功能:自定义成绩处理模块

"""


# 计算总分
def total(list):
    s = 0
    for i in list:
        s += i['score']
    return s


# 计算平均分
def aver(list):
    count = len(list)
    aver_score = total(list) / count
    return aver_score


# 按照成绩进行排序(降序)
def sort_score(list):
    dict = []
    count = len(list)
    for i in range(0, count - 1):
        for j in range(i + 1, count):
            if list[i]['score'] < list[j]['score']:
                dict = list[i]
                list[i] = list[j]
                list[j] = dict
    return list


#打印学生成绩单
def print_student(list):
    for i in list:
        print(i)
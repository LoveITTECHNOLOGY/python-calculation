"""
作者:魏嘉福
版本:1.0
日期:20/03/2020
功能:定义学生类，类的方法，计算总分，平均分和按成绩排序


"""

class Student:
    #构造方法,自动调用
    def __init__(self,List):
        self.list=List

    #按照成绩进行排序(降序)
    def sort_score(self):
        dict=[]
        count=len(self.list)
        for i in range(0, count-1):
            for j in range(i+1,count):
                if self.list[i]['score'] < self.list[j]['score']:
                    dict = self.list[i]
                    self.list[i]=self.list[j]
                    self.list[j]=dict
        return self.list
    def print_student(self):
        for i in self.list:
            print(i)



def main():
    student_list=[{'id': 'a1001','name': '张大山','score': 92},
                  {'id': 'a1002','name': '李晓丽','score': 82},
                  {'id': 'a1003','name': '赵志勇','score': 97}]
    #用类Student实例化一个对象stu_obj
    stu_obj=Student(student_list)


    #调用Student的放法sort_score
    student_list=stu_obj.sort_score()
    print('排序完成，排序后的学生信息显示如下:')
    stu_obj.print_student()


if __name__=='__main__':
    main()

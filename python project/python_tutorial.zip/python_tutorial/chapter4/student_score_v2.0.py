"""
作者:魏嘉福
版本·2.0
日期:20/03/2020
功能:自定义成绩处理模块
2.0新增功能:导入自定义模块

"""

"""
作者:魏嘉福
版本:1.0
日期:20/03/2020
功能:定义学生类，类的方法，计算总分，平均分和按成绩排序


"""
#导入自定义模块，总分，平均分，排序，打印成绩单
from chapter4 import score_operator
def main():
    student_list = [{'id': 'a1001', 'name': '张大山', 'score': 92},
                    {'id': 'a1002', 'name': '李晓丽', 'score': 82},
                    {'id': 'a1003', 'name': '赵志勇', 'score': 97}]
    #计算总分
    score_total=score_operator.total(student_list)
    print('总分是: {}'.format(score_total))


    #计算平均分
    score_aver=score_operator.aver(student_list)
    print('平均分是: {}'.format(score_aver))
    #进行排序
    score_sort=score_operator.sort_score(student_list)
    print('排序成功'.format(score_sort))


if __name__ == '__main__':
    main()

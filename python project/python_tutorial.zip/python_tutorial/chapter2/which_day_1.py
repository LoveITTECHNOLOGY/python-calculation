"""
作者:魏嘉福
版本:1.0
功能:输入日期（含年月日），判断这个日期是这一年的第几天
"""
# 导入detetime库
import datetime


def main():
    date_str = input('请输入日期(yyyy/mm/dd):')
    date_new = datetime.datetime.strptime(date_str, '%Y/%m/%d')
    # 分别得到日期的年，月，日
    year = date_new.year
    month = date_new.month
    day = date_new.day
    # 计算日期之间的月份的所有天数之和
    # 使用元组
    month_days_tuple = (31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
    days = sum(month_days_tuple[:month - 1]) + day
    # 判断闰年
    if (year % 400 == 0) or (year % 4 == 0) and (year % 100 != 0):
        if month > 2:
            days = day + 1
    print("这是{}年的第{}天".format(year,days))


if __name__ == '__main__':
    main()

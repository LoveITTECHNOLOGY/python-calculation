"""
作者:魏嘉福
版本:3.0
功能:输入日期（含年月日），判断这个日期是这一年的第几天
3.0新增功能，将判断闰年转换为函数
3.0新增功能，用集合实现月份日期的存储，将月份分类
"""
#导入detetime库
from datetime import datetime

#将定义函数判断闰年
def is_leap(year):
    '''
    :param year
    :return:是true,否false
    '''
    result=False
    if(year % 400==0) or((year %4 ==0) and (year % 100 !=0)):
        result=True
    return result



def main():
    date_str=input("请输入日期(yyy/mm/dd):")
    date_new=datetime.strptime(date_str,'%Y/%m/%d')
    #分别得到日期的年，月，日
    year=date_new.year
    month=date_new.month
    day=date_new.day
    #计算日期之间的月份的所有天数之和
    #用列表代替元组
    #用集合表示月份的天数，月份分类表示
    month_30days_set={4,6,9,11}
    month_31days_set={1,3,5,7,8,10,12}

    #初始化
    days=day
    for i in range(1,month):
        if i in month_30days_set:
            days=days+30
        elif i in month_31days_set:
            days=days+31
        else:
            days=days+28
    if is_leap(year)==True:
        days=days+1


    print('这是{}年的第{}天'.format(year,days))

if __name__=='__main__':
    main()
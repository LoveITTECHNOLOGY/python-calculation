"""
作者:魏嘉福
版本:1.0
功能:输入日期（含年月日），判断这个日期是这一年的第几天
2.0新增功能，将判断闰年转换为函数
"""
#导入detetime库
from datetime import datetime

#将定义函数判断闰年
def is_leap(year):
    '''
    :param year
    :return:是true,否false
    '''
    result=False
    if(year % 400==0) or((year %4 ==0) and (year % 100 !=0)):
        result=True
    return result



def main():
    date_str=input("请输入日期(yyy/mm/dd):")
    date_new=datetime.strptime(date_str,'%Y/%m/%d')
    #分别得到日期的年，月，日
    year=date_new.year
    month=date_new.month
    day=date_new.day
    #计算日期之间的月份的所有天数之和
    #用列表代替元组
    month_days_list=[31,28,31,30,31,30,31,31,30,31,30,31]
    if is_leap(year)==True:
        month_days_list[1]=29
    days=sum(month_days_list[:month-1])+day
    print('这是{}年的第{}天'.format(year,days))

if __name__=='__main__':
    main()
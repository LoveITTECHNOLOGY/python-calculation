"""
作者:魏嘉福
版本:4.0
功能:输入日期（含年月日），判断这个日期是这一年的第几天
4.0新增功能，将判断闰年转换为函数
4.0新增功能，用集合实现月份日期的存储，将月份分类
4.0新增功能，将月份对应的天数，进行字典的表示
"""
#导入detetime库
from datetime import datetime

#将定义函数判断闰年
def is_leap(year):
    '''
    :param year
    :return:是true,否false
    '''
    result=False
    if(year % 400==0) or((year %4 ==0) and (year % 100 !=0)):
        result=True
    return result



def main():
    date_str=input("请输入日期(yyy/mm/dd):")
    date_new=datetime.strptime(date_str,'%Y/%m/%d')
    #分别得到日期的年，月，日
    year=date_new.year
    month=date_new.month
    day=date_new.day
    #计算日期之间的月份的所有天数之和
    #用列表代替元组
    #用集合表示月份的天数，月份分类表示
    month_day_dict={1:31,2:28,3:31,4:30,5:31,6:30,
                    7:31,8:31,9:30,10:31,11:30,12:31}

    #初始化
    days=day
    for i in range(1,month):
        days=days+month_day_dict[i]
        #month_day_dict[i]得到的就是i这个间对应的值

    if is_leap(year)==True and month >2:
        days=days+1


    print('这是{}年的第{}天'.format(year,days))

if __name__=='__main__':
    main()
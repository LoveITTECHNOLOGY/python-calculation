"""
作者：
版本：v3.0
日期：20190730
功能：模拟投掷骰子
模拟投掷两个骰子，可视化
"""
import random
import matplotlib.pyplot as plt


def roll_dice():
    #     模拟投掷骰子
    roll = random.randint(1, 7)
    return roll


def main():
    # 主函数
    totle_times = 100
    # 初始化列表
    result_list = [0] * 12
    # 初始化点数列表
    roll_list = list(range(2, 13))
    roll_dict = dict(zip(roll_list, result_list))
    #  记录骰子结果
    roll1_list = []
    roll2_list = []

    for i in range(totle_times):
        roll1 = roll_dice()
        roll2 = roll_dice()

        roll1_list.append(roll1)
        roll2_list.append(roll2)

        for j in range(2, 13):
            if (roll1 + roll2) == j:
                roll_dict[j] += 1

    print(result_list)

    for i, result in roll_dict.items():
        print('点数：{} ，次数{}  频率 {}'.format(i, result, result / totle_times))

    # 数据可视化
    x = range(1, totle_times + 1)
    plt.scatter(x, roll1_list, c='red', alpha=0.5)
    plt.scatter(x, roll2_list, c='green', alpha=0.5)
    plt.show()
    # 数据可视化 默认设置值
    # x = range(1, totle_times + 1)
    # plt.scatter(x, roll1_list )
    # plt.scatter(x, roll2_list )
    # plt.show()

    print('end')


if __name__ == '__main__':
    main()


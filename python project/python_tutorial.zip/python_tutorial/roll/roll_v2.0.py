"""
作者：魏嘉福
版本：v2.0
日期：20190730
功能：模拟投掷骰子
模拟投掷两个骰子
"""
import random


def roll_dice():
    #     模拟投掷骰子
    roll = random.randint(1, 7)
    return roll


def main():
    # 主函数
    totle_times = 1000
    # 初始化列表
    result_list = [0] * 12
    # 初始化点数列表
    roll_list = list(range(2, 13))
    roll_dict = dict(zip(roll_list, result_list))

    for i in range(totle_times):
        roll1 = roll_dice()
        roll2 = roll_dice()

        for j in range(2, 13):
            if (roll1 + roll2) == j:
                roll_dict[j] += 1

    print(result_list)

    for i, result in roll_dict.items():
        print('点数：{} ，次数{}  频率 {}'.format(i, result, result / totle_times))

    print('end')


if __name__ == '__main__':
    main()


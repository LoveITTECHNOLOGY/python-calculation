"""
作者:魏嘉福
版本：2.0
日期:09/03/2020
1.0功能:简单通讯录管理稀土，打印员工信息
2.0 新增功能:能够指定的员工信息，找到就输出，未找到则显示内容
"""

def print_AddressBook(dict,phone):
    try:
        person_info=dict[phone]
        person_list=person_info.split(' ')
        print('电话号码:{},ID:{},姓名:{},城市:{}'.format(phone,person_list[0],person_list[1],person_list[2]))
    except:
        print('没有找到需要打印的员工信息')
def find_by_phone(dict,phone):
    is_find=False
    for phone in dict:
        if phone==phone:
            is_find=True
    return is_find



def main():
    address_book_dict={'13309406204':'1 晓华 武汉',
                       '1391234234':'2 李浩 北京',
                       '1391234234':'3 李浩  九江',
                       '15890281734':'4  王华 上海'}
    #id_str=input('请输入需要打印的员工工号:')
    #id=int(id_str)
    #print_AddressBook(address_book_dict,id)

    phone_str=input('请输入需要查找的员工手机号码:')
    phone=phone_str
    #调用函数
    #变量的作用域问题，局部变量
    is_find_main=find_by_phone(address_book_dict,phone)
    if is_find_main==True:
        print('查找成功，员工信息显示如下')
        print_AddressBook(address_book_dict,phone)
    else:
        print('查找失败，你所要查找的员工信息不存在')

if __name__=='__main__':
    main()
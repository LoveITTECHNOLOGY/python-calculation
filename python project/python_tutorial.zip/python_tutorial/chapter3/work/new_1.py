from chapter3.work import txgl
from chapter3.work import wjcz

def main():
    address_book_dict={1:'张晓 13800000000 武汉',
                       2:'李明 18500000000 北京',
                       3:'李浩 13912342345 九江',
                       4:'王华 1589028173 上海'}

    found_str = input('亲！请自定义查找员工的方式(输入序号即可):1:工号查找 2:姓名查找 3:电话查找 4:城市查找 5:删除员工 6:增加员工 7:读取文件:')

        #id_str=input('请输入需要打印的员工工号:')
        #id=int(id_str)
        #txgl.print_AddressBook(address_book_dict,id)

    if found_str == '1':
        id_str=input('请输入需要查找的员工工号:')
        id=int(id_str)
        #调用函数
        #变量的作用域问题，局部变量
        is_find_main=txgl.find_by_id(address_book_dict,id)
        if is_find_main==True:
            print('查找成功，员工信息显示如下')
            txgl.print_AddressBook(address_book_dict,id)
        else:
            print('查找失败，你所要查找的员工信息不存在')

    if found_str == '2':
         name=input('请输入查找员工姓名:')
         find_name_tuple=txgl.find_by_name(address_book_dict,name)
         if find_name_tuple[0]==True:
            print('查找成功，所有找到的员工信息显示如下!')
            for i in find_name_tuple[1]:
                txgl.print_AddressBook(address_book_dict,i)
         else:
            print('查找失败，你所需要查找的员工信息不存在')

    if found_str == '3':
        phone = input('请输入查找员工电话号码:')
        find_phone_tuple = txgl.find_by_phone(address_book_dict, phone)
        if find_phone_tuple[0] == True:
            print('查找成功，所有找到的员工信息显示如下!')
            for i in find_phone_tuple[1]:
                txgl.print_AddressBook(address_book_dict, i)
        else:
            print('查找失败，你所需要查找的员工信息不存在')

    if found_str == '4':
         city = input('请输入查找员工城市:')
         find_city_tuple = txgl.find_by_city(address_book_dict, city)
         if find_city_tuple[0] == True:
            print('查找成功，所有找到的员工信息显示如下!')
            for i in find_city_tuple[1]:
                txgl.print_AddressBook(address_book_dict, i)
         else:
            print('查找失败，你所需要查找的员工信息不存在')

    if found_str == '5':
        id_str=input('请输入需要删除的员工工号:')
        id=int(id_str)
        #调用函数，删除员工信息
        address_book_dict=wjcz.delete_by_id(address_book_dict,id)

    if found_str == '6':
        id_str=input('请输入需要增加的员工工号:')
        id=int(id_str)
        print('请输入需要增加的员工的详细信息')
        worker_info=input('姓名 电话号码 城市 :')
        #调用自定义函数：增加
        address_book_dict=wjcz.add_info(address_book_dict,id,worker_info)

        #write_file(address_book_dict)

    if found_str == '7':
        address_book_dict=wjcz.read_file()
        print('读取文件成功')
        for i in address_book_dict.keys():
            wjcz.print_AddressBook(address_book_dict,i)


if __name__=='__main__':
    main()
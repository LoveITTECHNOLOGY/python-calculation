def print_AddressBook(dict,id):
    try:
        person_info=dict[id]
        person_list=person_info.split(' ')
        print('ID:{},姓名:{},电话号码:{},城市:{} '.format(id,
                person_list[0],person_list[1],person_list[2]))
    except:
        print('没有找到员工信息')

def find_by_id(dict,id):
    is_find=False
    for i in dict.keys():
        if i==id:
            is_find=True
    return is_find
#用姓名查找
def find_by_name(dict,name):
    is_find=False
    find_list=[]
    for i in dict.keys():
        person_list=dict[i].split(' ')
        if name==person_list[0]:
            is_find=True
            find_list.append(i)
    #当函数有多个返回值
    return (is_find,find_list)

def find_by_phone(dict,phone):
    is_find=False
    find_list=[]
    for i in dict.keys():
        person_list=dict[i].split(' ')
        if phone==person_list[1]:
            is_find=True
            find_list.append(i)
    #当函数有多个返回值
    return (is_find,find_list)

def find_by_city(dict,city):
    is_find=False
    find_list=[]
    for i in dict.keys():
        person_list=dict[i].split(' ')
        if city==person_list[2]:
            is_find=True
            find_list.append(i)
    #当函数有多个返回值
    return (is_find,find_list)
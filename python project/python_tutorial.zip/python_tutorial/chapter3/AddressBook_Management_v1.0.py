"""
作者:魏嘉福
版本：1.0
日期:09/03/2020
1.0功能:简单通讯录管理稀土，打印员工信息
"""

def print_AddressBook(dict,id):
    try:
        person_info=dict[id]
        person_list=person_info.split(' ')
        print('ID:{},姓名:{},电话号码:{},城市:{}'.format(id,person_info[0],person_list[1],person_list[2]))
    except:
        print('没有找到需要打印的员工信息')


def main():
    address_book_dict={1:'张晓 1380000000 武汉',
                       2:'李明 1850000000 北京',
                       3:'李浩 1391234234 九江',
                       4:'王华 15890281734 上海'}
    id_str=input('请输入需要打印的员工工号:')
    id=int(id_str)
    print_AddressBook(address_book_dict,id)

if __name__=='__main__':
    main()
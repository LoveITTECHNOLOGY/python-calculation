"""
作者:魏嘉福
版本：5.0
日期:09/03/2020
1.0功能:简单通讯录管理稀土，打印员工信息
2.0 新增功能:能够指定的员工信息，找到就输出，未找到则显示内容
3.0 新增功能:删除指定的人员信息(ID)
4.0新增功能：增加员工信息(ID)
5.0新增功能用文件1实现持久化储存员工信息
"""
#自定义函数：打印员工信息1.0
def print_AddressBook(dict,id):
    try:
        person_info=dict[id]
        person_list=person_info.split(' ')
        print('ID:{},姓名:{},电话号码:{},城市:{}'.format(id,person_info[0],person_list[1],person_list[2]))
    except:
        print('没有找到需要打印的员工信息')
#自定义函数：查找员工信息2.0
def find_by_id(dict,id):
    is_find=False
    for i in dict.keys():
        if i==id:
            is_find=True
    return is_find
#自定义函数：删除指定的员工信息3.0
def delete_by_id(dict,id):
    #调用了查找函数
    is_find_remove=find_by_id(dict,id)
    if is_find_remove==True:
        print('需要删除的员工信息如下!')
        print_AddressBook(dict,id)
        y_or_n=input('请确认是否删除，删除后将无法恢复(y/n)?')
        if y_or_n=='y':
            del(dict[id])
            print('删除成功，当前的员工通讯录信息如下!')
            for i in dict.keys():
                #调用了打印函数
                print_AddressBook(dict,i)
        else:
            print('删除操作未执行，员工通讯录没有发生任何变化！')

    else:
        print('删除失败，没有找到需要删除的员工信息')
    return dict

#自定义函数，增加员工信息
def add_info(dict,id,info):
    for i in dict.keys():
        if i == id:
            print('工号已存在，无法增加!')
            return dict
    dict[id]=info

    print('员工信息增加成功，当前通讯录显示如下:')
    for i in dict.keys():
       print_AddressBook(dict,i)
    return dict
#定义函数，写文件
def write_file(dict):
    """
    1.打开文件
    2操作文件，读写 write/closse 方式 r/c
    3关闭文件：close


    :param dict:
    :return:
    """
    f=open('address_book.txt','w')
    for i in dict.keys():
        dict_value_list=dict[i].split(',')
        f.write('{}:{}\n'.format(i,dict[i]))
    f.close()

def main():
    address_book_dict={1:'张晓 1380000000 武汉',
                       2:'李明 1850000000 北京',
                       3:'李浩 1391234234 九江',
                       4:'王华 15890281734 上海'}
    #id_str=input('请输入需要打印的员工工号:')
    #id=int(id_str)
    #print_AddressBook(address_book_dict,id)

    #id_str=input('请输入需要查找的员工工号:')
    #id=int(id_str)
    #调用函数
    #变量的作用域问题，局部变量
    #is_find_main=find_by_id(address_book_dict,id)
    #if is_find_main==True:
        #print('查找成功，员工信息显示如下')
        #print_AddressBook(address_book_dict,id)
    #else:
        #print('查找失败，你所要查找的员工信息不存在')
    id_str=input('请输入需要删除的员工工号:')
    id=int(id_str)
    #调用函数，删除员工信息
    address_book_dict=delete_by_id(address_book_dict,id)

    #id_str=input('请输入需要增加的员工工号:')
    #id=int(id_str)
    #print('请输入需要增加的员工的详细信息')
    #worker_info=input('姓名 电话号码 城市 :')
    #调用自定义函数：增加
    #address_book_dict=add_info(address_book_dict,id,worker_info)
    #write_file(address_book_dict)


if __name__=='__main__':
    main()
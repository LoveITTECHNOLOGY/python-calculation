def print_AddressBook(dict,id):
    try:
        person_info=dict[id]
        person_list=person_info.split(' ')
        print('ID:{},姓名:{},电话号码:{},城市:{} '.format(id,
                                                  person_list[0], person_list[1], person_list[2]))
    except:
        print('没有找到需要打印的员工信息')

def find_by_id(dict,id):
    is_find=False
    for i in dict.keys():
        if i==id:
            is_find=True
    return is_find

def delete_by_id(dict,id):
    #调用了查找函数
    is_find_remove=find_by_id(dict,id)
    if is_find_remove==True:
        print('需要删除的员工信息如下!')
        print_AddressBook(dict,id)
        y_or_n=input('请确认是否删除，删除后将无法恢复(y/n)?')
        if y_or_n=='y':
            del(dict[id])
            print('删除成功，当前的员工通讯录信息如下!')
            for i in dict.keys():
                #调用了打印函数
                print_AddressBook(dict,i)
        else:
            print('删除操作未执行，员工通讯录没有发生任何变化！')

    else:
        print('删除失败，没有找到需要删除的员工信息')
    return dict

#自定义函数，增加员工信息
def add_info(dict,id,info):
    for i in dict.keys():
        if i == id:
            print('工号已存在，无法增加!')
            return dict
    dict[id]=info
    print('员工信息增加成功，当前通讯录显示如下:')
    for i in dict.keys():
       print_AddressBook(dict,i)
    return dict

def write_file(dict):
    '''
    1.打开文件：open
    2.操作文件:read,write
    3.关闭文件:cloase
    '''
    f=open('worker.txt','w')
    for i in dict.keys():
        dict_value_list=dict[i].split(',')
        f.write('{}:{}\n'.format(i,dict[i]))
    f.close()

def read_file():
    #定义空字典
    dict={}
    f=open('worker.txt','r')
    for line in f.readlines():
        line_list=line.split(':')
        id=line_list[0]
        info=line_list[1]
        dict[eval(id)]=info
    return  dict
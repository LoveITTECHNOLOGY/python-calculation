'''
作者：魏嘉福
版本：8.0
（1）查询：按特定条件查找员工（查询条件设计应包含：主关键字查询（如工号）、次关键字查询（如姓名）和多条件查询（如姓名+职称））。

（2）修改：按工号对某个员工的某项信息进行修改。

（3）插入：加入新员工的信息。

（4）删除：按工号删除已离职员工的信息。

（5）打印：输出某个指定员工的信息。

（6）排序：按指定条件对所有员工的信息进行排序。

3．员工信息存储在相应的数据文件worker.txt中。
'''

# 文件操作类
class file:
    '''

    '''

    def __init__(stu_boj1, new_addressbook):
        stu_boj1.new_addressbook = new_addressbook

    # 读员工信息
    # 将文件里面的信息放入一个新的字典中
    def read_file(stu_boj1):
        '''

        :return:
        '''
        # 定义字典存放文件
        dict = {}
        f = open('worker.txt', 'r')
        for line in f.readlines():
            # 将每一项值用字符串分隔开 将键和值分离
            file_list = line.split(':')
            # 得到键
            id = int(file_list[0])
            # 得到值
            value = file_list[1]
            # 将值放到字典中
            dict[id] = value
        # 返回字典
        return dict
        f.close()

    # 写文件函数
    def write_file(stu_boj1, dict):
        '''

        :return:
        '''
        # 打开一个新的文件
        f = open('worker.txt', 'w')
        # 写文件
        for i in dict.keys():
            f.write('{}:{}\n'.format(i, dict[i]))
        f.close()

# 员工类
class work(file):

    def __init__(stu_obj, new_addressbook):
        stu_obj.new_addressbook = new_addressbook



    # 删除函数
    def delete_by_id(stu_obj, dict,id):
        '''

        :param dict:
        :param id:
        :return:
        '''

        #
        is_find_del = stu_obj.find_by_id(dict, id)
        if is_find_del == True:
            print('需要删除的员工信息如下：')
            stu_obj.print_person_info(dict, id)
            y_or_no = input('请确定是否删除后将无法恢复(y/n)?')
            if y_or_no == 'y':
                del (dict[id])
                print('删除成功，当前员工的通讯录显示如下:')
                for i in dict.keys():
                    stu_obj.print_person_info(dict, i)

                work().write_file(dict)
            else:
                print('删除未执行，员工通讯录未做任何修改！')
        else:
            print('您当前要删除的员工信息不存在！')

    # 添加信息
    def add_info(stu_obj, dict, id, info):
        '''
        在字典中添加人员信息的语法：
        dict[id] = value
        :return:
        '''
        '''
             此处 出现bug 当增加的员工工号在原来的字典中已经存在 
             则增加的人员信息会将之前的工号的信息覆盖，在进行添加值到字典之前要将添加操作拦截下来

        '''
        # 拦截添加的id在字典中已经存在的情况 遍历所有的key
        for i in dict.keys():
            if i == id:
                print('工号已存在，无法增加！')

        # 打开一个新的文件
        f = open('worker.txt', 'a')
        # 写文件
        f.write('{}:{}\n'.format(id, info))
        f.close()
        print('员工信息增加成功，当前通讯录信息显示如下：')
        file_dict =work.read_file()
        for i in file_dict.keys():
            stu_obj.print_person_info(file_dict, i)
# 修改
    def edit_info(stu_obj, dict, id, info):
        for i in dict.keys():
            if i == id:
                stu_obj.print_person_info(dict, i)
                # 打开一个新的文件
                f = open('worker.txt', 'r+')
                # 写文件
                f.write('{}:{}\n'.format(id, info))
                f.close()
                print('员工信息修改成功，当前通讯录信息显示如下：')
                file_dict = work.read_file()
                for i in file_dict.keys():
                    stu_obj.print_person_info(file_dict, i)







    def find_by_all(stu_obj, dict, Value_type):
        '''

        :return:
        '''
        # 初始化 is_find 和定义find_list
        is_find = False
        find_list = []
        # 分支判断
        # 若进入的值类型是个大于0 的数字
        if type(Value_type) == int:
            for i in dict.keys():
                if Value_type == eval(dict[i].split(' ')[1]):
                    is_find = True
                    find_list.append(i)
                elif Value_type == eval(dict[i].split(' ')[4]):
                    is_find = True
                    find_list.append(i)

        else:
            for i in dict.keys():
                if Value_type == dict[i].split(' ')[0]:
                    is_find = True
                    find_list.append(i)
                    # return(is_find,find_list)
                elif Value_type == dict[i].split(' ')[2]:
                    is_find = True
                    find_list.append(i)
                elif Value_type == dict[i].split(' ')[3]:
                    is_find = True
                    find_list.append(i)
                elif Value_type == dict[i].split(' ')[5]:
                    is_find = True
                    find_list.append(i)
                elif Value_type == dict[i].split(' ')[6][:-1]:
                    is_find = True
                    find_list.append(i)

        return (is_find, find_list)

    # id查找方法
    def find_by_id(stu_obj, dict, id):
        '''

        :param dict:
        :param id:
        :return:
        '''
        # 初始化is_find
        is_find = False
        # 遍历keys
        for i in dict.keys():
            if i == id:
                is_find = True
        return is_find

    # 打印员工信息
    def print_person_info(stu_obj, dict, id):
        dict_list = dict[id].split(' ')
        try:
            print('ID:{} name:{} phone:{} city:{} sex:{} birth:{} education:{} post:{}'.format(id, dict_list[0],
            dict_list[1], dict_list[2],dict_list[3],dict_list[4],dict_list[5],dict_list[6][:-1]))
        except KeyError:
            print('您要查找的员工信息不存在！请核对！')
        except:
            print('程序异常，请联系管理员！')
# # 读员工信息
# # 将文件里面的信息放入一个新的字典中
# def read_file():
#     '''
#
#     :return:
#     '''
#     # 定义字典存放文件
#     dict = {}
#     f = open('new_addressbook.txt','r')
#     for line in f.readlines():
#     # 将每一项值用字符串分隔开 将键和值分离
#       file_list = line.split(':')
#       # 得到键
#       id = int(file_list[0])
#       # 得到值
#       value = file_list[1]
#       # 将值放到字典中
#       dict[id] = value
#     # 返回字典
#     return dict
#     f.close()
# # 写文件函数
# def write_file(dict):
#     '''
#
#     :return:
#     '''
#     # 打开一个新的文件
#     f = open('new_addressbook.txt','w')
#     # 写文件
#     for i in dict.keys():
#         f.write('{}:{}\n'.format(i, dict[i]))
#     f.close()
# 主函数
def main():
    '''

    :return:
    '''

    # 创建一个字典工号、姓名、性别、出生年月、学历、职务、电话、住址
    new_addressbook = {1: '张晓 1380000000 武汉 男 19980101 本科 程序员',
                       2: '李明 1850000000 北京 男 20200105 专科 老师',
                       3: '李浩 13912341234 九江 男 19970501 初中 销售员',
                       4: '吴涵 18976564234 上海 男 19960401 小学 自营',
                       5: '韩梅梅 1244566322 北京 男 19950301 硕士 教授',
                       6: '王大弄 4334444444 河北 男 19940201 博士 教授'}
    stu_obj = work(new_addressbook)
    stu_obj1 = file(new_addressbook)
    # 利用选择和循环结构由用户决定是否继续进行
    y_or_no = input('亲！是否运行程序请输入(y/n)?')
    # go_str = input('请输入您需要对用户通讯录执行的操作(输入对应数字即可):'
    #                '\n1:打印人员信息 2:查找人员信息 3：增加人员信息\n'
    #                '4：删除人员信息 5:写文件 6:读文件:\n')
    # 循环执行
    while y_or_no == 'y':
        go_str = input('请输入您需要对用户通讯录执行的操作(输入对应数字即可):'
                       '\n1:打印人员信息 2:查找人员信息 3：增加人员信息\n'
                       '4：删除人员信息 5:写文件 6:读文件 7:修改员工信息:\n 8：信息排序\n')
        # 读文件打印
        if go_str == '1':
            # 打印所有员工信息
            # 调用读文件函数
            file_dict = stu_obj1.read_file()
            for i in file_dict.keys():
                stu_obj.print_person_info(file_dict, i)

        elif go_str == '2':
            found_str = input('亲！请自定义查找员工的方式(输入序号即可):1:工号查找 '
                              '2:姓名查找 3:电话查找 4:城市查找 5:性别查找 6:生日查找 7:学历查找 8:职务查找 9:信息排序')

            if found_str == '1':
                id_str = input('请输入需要查找的员工的工号：')
                id = int(id_str)
                file_dict = stu_obj1.read_file()
                is_find_main = stu_obj.find_by_id(file_dict, id)
                if is_find_main == True:
                    # 找到
                    print('查找成功，找到的员工通讯录信息显示如下：')
                    stu_obj.print_person_info(file_dict, id)
                else:
                    print('您需要查找的员工信息不存在！')
            elif found_str == '2':
                name = input('请输入需要查找的员工的姓名：')
                file_dict = stu_obj1.read_file()
                is_find_main = stu_obj.find_by_all(file_dict, name)
                id = (is_find_main[1])[0]
                if is_find_main[0] == True:
                    # 找到
                    print('查找成功，找到的员工通讯录信息显示如下：')
                    for i in is_find_main[1]:
                        stu_obj.print_person_info(file_dict, i)
                else:
                    print('您需要查找的员工信息不存在！')
            elif found_str == '3':
                phone_str = input('请输入需要查找的员工的电话：')
                phone = int(phone_str)
                file_dict = stu_obj1.read_file()
                is_find_main = stu_obj.find_by_all(file_dict, phone)
                if is_find_main[0] == True:
                    # 找到
                    print('查找成功，找到的员工通讯录信息显示如下：')
                    for i in is_find_main[1]:
                        stu_obj.print_person_info(file_dict, i)
                else:
                    print('您需要查找的员工信息不存在！')
            elif found_str == '4':
                city = input('请输入需要查找的员工的城市：')
                file_dict = stu_obj1.read_file()
                is_find_main = stu_obj.find_by_all(file_dict, city)
                if is_find_main[0] == True:
                    # 找到
                    print('查找成功，找到的员工通讯录信息显示如下：')
                    for i in is_find_main[1]:
                        stu_obj.print_person_info(file_dict, i)
                else:
                    print('您需要查找的员工信息不存在！')
            elif found_str == '5':
                sex = input('请输入需要查找的员工的性别：')
                file_dict = stu_obj1.read_file()
                is_find_main = stu_obj.find_by_all(file_dict, sex)
                if is_find_main[0] == True:
                    # 找到
                    print('查找成功，找到的员工通讯录信息显示如下：')
                    for i in is_find_main[1]:
                        stu_obj.print_person_info(file_dict, i)
                else:
                    print('您需要查找的员工信息不存在！')
            elif found_str == '6':
                birth_str = input('请输入需要查找的员工的生日：')
                birth = int(birth_str)
                file_dict = stu_obj1.read_file()
                is_find_main = stu_obj.find_by_all(file_dict, birth)
                if is_find_main[0] == True:
                    # 找到
                    print('查找成功，找到的员工通讯录信息显示如下：')
                    for i in is_find_main[1]:
                        stu_obj.print_person_info(file_dict, i)
                else:
                    print('您需要查找的员工信息不存在！')
            elif found_str == '7':
                education = input('请输入需要查找的员工的学历：')
                file_dict = stu_obj1.read_file()
                is_find_main = stu_obj.find_by_all(file_dict, education)
                if is_find_main[0] == True:
                    # 找到
                    print('查找成功，找到的员工通讯录信息显示如下：')
                    for i in is_find_main[1]:
                        stu_obj.print_person_info(file_dict, i)
                else:
                    print('您需要查找的员工信息不存在！')

            else:
                post = input('请输入需要查找的员工的职务：')
                file_dict = stu_obj1.read_file()
                is_find_main = stu_obj.find_by_all(file_dict, post)
                if is_find_main[0] == True:
                    # 找到
                    for i in is_find_main[1]:
                        stu_obj.print_person_info(file_dict, i)
                else:
                    print('您需要查找的员工信息不存在！')

        elif go_str == '3':
            id_str = input('请输入需要增加的员工工号：')
            id = int(id_str)
            print('请输入需要增加的员工的详细信息')
            worker_info = input('姓名 电话号码 城市 性别 生日 学历 职务:')
            file_dict = stu_obj1.read_file()
            # 调用自定义添加人员信息函数
            stu_obj.add_info(file_dict, id, worker_info)
        elif go_str == '4':
            id_str = input('请输入需要删除的员工工号：')
            id = int(id_str)
            file_dict = stu_obj1.read_file()
            # 调用删除函数
            stu_obj.delete_by_id(file_dict, id)
        elif go_str == '5':
            stu_obj1.write_file(new_addressbook)
            print('通讯录信息已写入文件')
        elif go_str == '6':
            # 调用read_file
            address_book_dict = stu_obj1.read_file()
            print('读文件成功，员工通讯录信息如下：')
            # 遍历字典
            for i in address_book_dict.keys():
                stu_obj.print_person_info(address_book_dict, i)
        elif go_str == '7':
            id_str = input('请输入需要修改的员工工号：')
            id = int(id_str)
            print('请输入需要修改的员工的详细信息')
            worker_info = input('姓名 电话号码 城市 性别 生日 学历 职务:')
            file_dict = stu_obj1.read_file()
            # 调用自定义添加人员信息函数
            stu_obj.edit_info(file_dict, id, worker_info)
        elif go_str=='8':
            # 调用read_file
            address_book_dict = stu_obj1.read_file()
            print('排序成功，员工通讯录信息如下：')
            # 遍历字典
            for i in address_book_dict.keys():
                stu_obj.print_person_info(address_book_dict, i)

        y_or_no = input('亲！是否运行程序请输入(y/n)?')

    print('程序已退出！')


if __name__ == '__main__':
    main()





"""
类的继承和多态
需求
1 人有辛明，性别
2教师有姓名，性别，讲课课程
3学生有姓名，性别，课程，课堂成绩
4 打印人的信息，要求有身份何姓名
"""


# 定义类，描述人, object表示Person类是父类/基类
class Person(object):
    # 构造方法
    def __init__(self, name, gender):
        self.name = name
        self.gender = gender

    # 打印人员信息
    def whoAmI(self):
        print('I am a person, my name is {}'.format(self.name))


# 创建人类的实例化
p = Person('mike', 12)
p.whoAmI()


class Teacher(Person):
    # 构造方法
    def __init__(self, name, gender, course):
        super(Teacher, self).__init__(name, gender)
        self.course = course

    # 方法的重载，重写
    # 父类和子类有完全相同的方法名，不同的效果，多态
    def whoAmI(self):
        print('I am a techer my name is {}'.format(self.name))


t = Teacher('Elanie', 'Femail', 'math')
# 使用的是子类Teacher重载的whoAmI的方法
t.whoAmI()
# 定义学生类

"""
1.模拟栈操作原理

"""
# 栈操作

class Stack():
    # 初始化
    def __init__(self):
        # 定义了一个空栈,stack:类的属性
        self.stack = []
    # 进栈
    def push(self,value):
        self.stack.append(value)
        return True
    # 出栈
    def pop(self):
        # 先判断栈是否为空
        if len(self.stack) == 0:
            return False
        else:
            item = self.stack.pop()
            return item
    # 栈顶元素
    def top(self):
        # 先判断栈是否为空
        if self.stack:
            return self.stack[-1]
        else:
            return False
    # 是否为空栈
    def isnone(self):
        if len(self.stack) == 0:
            return True
        else:
            return False
    # 栈的长度
    def length(self):
        return len(self.stack)
    def view(self):
        return ','.join(self.stack)

# 创建对象
stack1 = Stack()

# 调用方法
print(stack1.isnone())
print(stack1.length())
print(stack1.push('westos'))
print(stack1.length())
print(stack1.isnone())
print(stack1.pop())
print(stack1.isnone())
print(stack1.top())
print(stack1.push('linux'))
print(stack1.push('python'))
print(stack1.view())
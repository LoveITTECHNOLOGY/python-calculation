""""
1.房子有户型，总面积和家具名称列表，新房子没有任何的家具

2.家具有名字和占地面积，其中
          床： 占4平米
        衣柜： 占2平面
        餐桌： 占1.5平米

3.将以上三件家具添加到房子中

4.打印房子时，要求输出:户型，总面积，剩余面积，家具名称列表
分析:

# 1.由于要将家具放入房子中,所以需要先创建家具类

# 2.家具类:
#   (1)属性:名字(name),占地面积(area)
#   (2)对象:床(bed),衣柜(closet),餐桌(table)

# 3.房子类:
#   (1)属性:户型(house_style),总面积(zarea),
#      家具名称列表(namelist) (新房子没有任何的家具,即初始家具名称列表为空列表)
#      剩余面积(farea) (由于打印房子时,要求输出'剩余面积',所以剩余面积为房子的隐含属性)
#   (2)方法:添加家具(add_item)"""
# 1.定义家具类
class furniture():
    # 初始化; name,area:类的属性(家具名称 占地面积)
    def __init__(self,name,area):
        self.name = name
        self.area = area
    # str方法:规范化(输出信息)
    def __str__(self):
        return '%s占%.2f平米' %(self.name,self.area)

# 1).创建家具对象
bed = furniture('bed',4)
closet = furniture('closet',2)
table = furniture('table',1.5)

# print(bed)
# print(closet)
# print(table)

# 2.定义房子类
class house():
    # 初始化, house_style zarea:类的属性(户型,总面积)
    def __init__(self,house_style,zarea):
        self.house_style= house_style
        self.zarea = zarea
        # farea: 类的属性(剩余面积)
        self.farea = zarea
        # namelist: 类的属性(家具名称列表)
        self.namelist = []
    # str方法:规范化(输出信息)
    def __str__(self):
        return '户型:%s 总面积:%.2f 剩余面积:%.2f 家具:%s' %(self.house_style,self.zarea,self.farea,self.namelist )
    ### 定义添加家具方法
    # item:家具类的一个对象
    def add_item(self,item):
        #  1.判断房子剩余面积是否能够容纳要添加的家具面积
        if self.farea >= item.area:
            # 2.append方法:将家具添加到家具列表中
            self.namelist.append(item.name)
            # 3.计算剩余面积
            self.farea -= item.area
        else:
            print(' %s占地面积过大,无法摆放此家具.....' %item.name)

# 2).创建房子对象
house1 = house('两室一厅',50)
print(house1)
# 3).将家具添加到房子中(调用方法)
house1.add_item(bed)
print(bed)
print(house1)

house1.add_item(closet)
print(closet)
print(house1)



# 创建房子对象
house2 = house('一室一厅',5)
print(house2)
house2.add_item(bed)
print(bed)
print(house2)

# 将家具添加到房子中(调用方法)
house2.add_item(table)
print(table)
print(house2)
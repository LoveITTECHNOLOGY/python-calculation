'''
    需求：
    1 银行账户，有如下属性：
        姓名(username) 账号(card_id) 余额(balance)
    2 能够执行的操作：对应类的方法
        存钱 deposit
        取钱 withdraw
        转账 transfer
        打印流水 history
    3 业务分析
        取钱？
        转账？：有余额，并且余额大于取钱的数额
        存钱、取钱、转账，涉及到了账户记录的更新，都需要写入到流水中
'''
from datetime import datetime

# 定义账户类
class BankAccount(object):
    # 构造方法
    def __init__(self, username, card_id, balance):
        self.username = username
        self.card_id = card_id
        self.balance = balance
        # 保存账户流水的列表，账户创建时，流水为空
        self.history_list = []

    @classmethod
    def get_current_time(cls):
        now = datetime.now()
        current_time = now.strftime('%Y-%m-%d %H:%M:%S')
        return current_time

    def is_amount_legal(self, amount):
        if not isinstance(amount, (float, int)):
            return False
        if amount <= 0:
            return False
        return True

    # 方法：存钱
    def deposit(self, amount):
        '''
        判断存入的金额amount是否合法
        :param amount:
        :return:
        '''
        if self.is_amount_legal(amount) == False:
            print('金额不合法，无法存钱！')
            return
        self.balance += amount
        log = '{operate_time} 存入 {amount}元 账户余额 {balance}元'.\
            format(operate_time = self.get_current_time(), amount = amount,
                   balance = self.balance)
        self.history_list.append(log)


    # 方法：取钱
    def withdraw(self, amount):
        '''
        1 判断金额是否合法
        2 判断账户的余额是否合法
        :param amount:
        :return:
        '''
        if self.is_amount_legal(amount) == False:
            print('金额不合法，无法取钱！')
            return
        else:
            if amount > self.balance:
                print('余额不足，无法取钱！')
            else:
                self.balance -= amount
                log = '{operate_time} 取出 {amount}元 账户余额 {balance}元'.\
                    format(operate_time = self.get_current_time(), amount = amount,
                           balance = self.balance)
                self.history_list.append(log)


    # 方法：转账
    def transfer(self, another, amount):
        '''
        转账涉及到两个账户，一个是存钱，一个是取钱
        而且是先取后存
        :param amount:
        :param another:
        :return:
        '''
        if self.is_amount_legal(amount) == False:
            print('金额不合法，无法转账！')
        else:
            if amount > self.balance:
                print('余额不足，无法转账！')
            else:
                # another.accept_transfer(self, amount)
                self.balance -= amount
                log = '{operate_time} 向 {username} 转帐 {amount}元 账户余额 {balance}元'. \
                    format(operate_time=self.get_current_time(),
                           username=another.username, amount=amount,
                           balance = self.balance)
                self.history_list.append(log)
                another.balance += amount
                log = '{operate_time} 收到 {username} 转来的 {amount}元 账户余额 {balance}元'.\
                    format(operate_time = self.get_current_time(),
                           username = self.username, amount = amount, balance = another.balance)
                self.history_list.append(log)


    # 方法，打印流水
    def history(self):
        for log in self.history_list:
            print(log)


def main():
    account1 = BankAccount('李明', '248252543', 4932.13)
    account2 = BankAccount('王红', '429845363', 3211.9)

    account1.deposit(400)  # 存钱
    account1.withdraw(300)  # 取钱

    account1.transfer(account2, 1024)  # 转账

    account1.history()
    account2.history()


if __name__ == '__main__':
    main()
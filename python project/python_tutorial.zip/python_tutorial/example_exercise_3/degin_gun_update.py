"""
1.士兵瑞恩有一把AK47
2.士兵可以开火(士兵开火扣动的是扳机)
3.枪 能够 发射子弹(把子弹发射出去)
4.枪 能够 装填子弹 --增加子弹的数量
Soldier                     Gun
-------------               -----------------
name                        model
gun                         bullet_count #子弹数量足够多才能完成射击的动作
-------------               -----------------
__init__(self):                 __init__(self):
fire(self):                 add_bullet(self,count):#装填子弹的
                            shoot(self):
1.由于士兵瑞恩有一把AK47，士兵可以开火。故需要先创建枪类

2.枪类（Gun）：
     （1）属性：型号（model），子弹数目（bullet_count）
     （2）方法：发射子弹（shoot），装填子弹（add_bullet）

3.士兵类（Soldier）
     （1）属性：姓名（name），枪名（Gun）
     （2）方法：开火（fire）


"""
# 定义枪类
class Gun():
	# 初始化
    def __init__(self,model):
        self.model = model
        self.bullet_count = 0
    # 规范化
    def __str__(self):
        return '%s有%d发子弹' %(self.model,self.bullet_count)
    # 定义方法
    def shoot(self):
        if self.bullet_count > 0:
            print('发射子弹....')
            self.bullet_count -= 1
        else:
            print('枪内无子弹，无法发射....')
    def add_bullet(self,count):
        self.bullet_count += count
        print('装填子弹:%s颗....' %count)

# 定义士兵类
class Soldier():
    # 初始化
    def __init__(self,name):
        self.name = name
        self.Gun = None
    # 定义方法（关联枪类）
    def fire(self):
        if self.Gun == None:
            print('%s还没有枪...' %self.name)
        else:
            self.Gun.add_bullet(10)
            print('开火....')
            self.Gun.shoot()

# 创建枪对象
AK47=Gun('AK47')
print(AK47)
#调用方法

AK47.add_bullet(10)
AK47.shoot()
print(AK47)

# 创建士兵对象
瑞恩=Soldier('瑞恩')
# 调用方法
瑞恩.fire()
瑞恩.Gun = AK47
瑞恩.fire()
print(AK47)